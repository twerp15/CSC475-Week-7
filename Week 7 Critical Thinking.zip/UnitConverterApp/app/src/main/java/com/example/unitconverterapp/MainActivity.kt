package com.example.unitconverterapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val inputValue = findViewById<EditText>(R.id.input_value)
        val fromUnitSpinner = findViewById<Spinner>(R.id.from_unit)
        val toUnitSpinner = findViewById<Spinner>(R.id.to_unit)
        val convertButton = findViewById<Button>(R.id.convert_button)
        val resultText = findViewById<TextView>(R.id.result_text)
        val units = arrayOf("Celsius", "Fahrenheit", "Meters", "Feet", "Kilograms", "Pounds")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, units)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        fromUnitSpinner.adapter = adapter
        toUnitSpinner.adapter = adapter
        convertButton.setOnClickListener {
            val input = inputValue.text.toString().toDoubleOrNull()
            val fromUnit = fromUnitSpinner.selectedItem.toString()
            val toUnit = toUnitSpinner.selectedItem.toString()
            if (input == null) {
                resultText.text = "Please enter a valid number"
                return@setOnClickListener
            }
            val result = try {
                when (fromUnit) {
                    "Celsius", "Fahrenheit" -> Converter.convertTemperature(input, fromUnit, toUnit)
                    "Meters", "Feet" -> Converter.convertLength(input, fromUnit, toUnit)
                    "Kilograms", "Pounds" -> Converter.convertWeight(input, fromUnit, toUnit)
                    else -> throw IllegalArgumentException("Invalid unit selection")
                }
            } catch (e: IllegalArgumentException) {
                resultText.text = "Invalid conversion selected."
                return@setOnClickListener
            }
            resultText.text = "Result: $result $toUnit"
        }
    }
}