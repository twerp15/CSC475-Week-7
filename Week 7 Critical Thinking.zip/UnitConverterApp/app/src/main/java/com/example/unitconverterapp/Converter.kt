package com.example.unitconverterapp
class Converter {

    companion object {
        fun convertTemperature(value: Double, fromUnit: String, toUnit: String): Double {
            return when (fromUnit to toUnit) {
                "Celsius" to "Fahrenheit" -> value * 9 / 5 + 32
                "Fahrenheit" to "Celsius" -> (value - 32) * 5 / 9
                "Celsius" to "Kelvin" -> value + 273.15
                "Kelvin" to "Celsius" -> value - 273.15
                else -> throw IllegalArgumentException("Unsupported temperature conversion")
            }
        }

        fun convertLength(value: Double, fromUnit: String, toUnit: String): Double {
            return when (fromUnit to toUnit) {
                "Meters" to "Feet" -> value * 3.28084
                "Feet" to "Meters" -> value / 3.28084
                else -> throw IllegalArgumentException("Unsupported length conversion")
            }
        }

        fun convertWeight(value: Double, fromUnit: String, toUnit: String): Double {
            return when (fromUnit to toUnit) {
                "Kilograms" to "Pounds" -> value * 2.20462
                "Pounds" to "Kilograms" -> value / 2.20462
                else -> throw IllegalArgumentException("Unsupported weight conversion")
            }
        }
    }
}