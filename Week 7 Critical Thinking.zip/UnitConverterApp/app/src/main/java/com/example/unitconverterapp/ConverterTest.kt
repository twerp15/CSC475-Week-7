package com.example.unitconverterapp
import org.junit.Assert.assertEquals
import org.junit.Test
class ConverterTest {
    @Test
    fun testConvertCelsiusToFahrenheit() {
        val result = Converter.convertTemperature(25.0, "Celsius", "Fahrenheit")
        assertEquals(77.0, result, 0.01)
    }
    @Test
    fun testConvertMetersToFeet() {
        val result = Converter.convertLength(1.0, "Meters", "Feet")
        assertEquals(3.28084, result, 0.0001)
    }
    @Test
    fun testConvertKilogramsToPounds() {
        val result = Converter.convertWeight(1.0, "Kilograms", "Pounds")
        assertEquals(2.20462, result, 0.0001)
    }
}